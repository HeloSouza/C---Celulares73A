﻿namespace Celulares73A.Desktop
{
    partial class frmComprar
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblMod = new System.Windows.Forms.Label();
            this.lblFab = new System.Windows.Forms.Label();
            this.lblQuant = new System.Windows.Forms.Label();
            this.lblPes = new System.Windows.Forms.Label();
            this.lblDimen = new System.Windows.Forms.Label();
            this.lblQuantidade = new System.Windows.Forms.Label();
            this.lblPeso = new System.Windows.Forms.Label();
            this.lblDimensoes = new System.Windows.Forms.Label();
            this.lblModelo = new System.Windows.Forms.Label();
            this.lblFabricante = new System.Windows.Forms.Label();
            this.lblPreco = new System.Windows.Forms.Label();
            this.lblDesconto = new System.Windows.Forms.Label();
            this.btnComprar = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lblMod
            // 
            this.lblMod.AutoSize = true;
            this.lblMod.Location = new System.Drawing.Point(12, 70);
            this.lblMod.Name = "lblMod";
            this.lblMod.Size = new System.Drawing.Size(45, 13);
            this.lblMod.TabIndex = 3;
            this.lblMod.Text = "Modelo:";
            // 
            // lblFab
            // 
            this.lblFab.AutoSize = true;
            this.lblFab.Location = new System.Drawing.Point(12, 30);
            this.lblFab.Name = "lblFab";
            this.lblFab.Size = new System.Drawing.Size(60, 13);
            this.lblFab.TabIndex = 2;
            this.lblFab.Text = "Fabricante:";
            // 
            // lblQuant
            // 
            this.lblQuant.AutoSize = true;
            this.lblQuant.Location = new System.Drawing.Point(12, 184);
            this.lblQuant.Name = "lblQuant";
            this.lblQuant.Size = new System.Drawing.Size(65, 13);
            this.lblQuant.TabIndex = 9;
            this.lblQuant.Text = "Quantidade:";
            // 
            // lblPes
            // 
            this.lblPes.AutoSize = true;
            this.lblPes.Location = new System.Drawing.Point(12, 148);
            this.lblPes.Name = "lblPes";
            this.lblPes.Size = new System.Drawing.Size(34, 13);
            this.lblPes.TabIndex = 8;
            this.lblPes.Text = "Peso:";
            // 
            // lblDimen
            // 
            this.lblDimen.AutoSize = true;
            this.lblDimen.Location = new System.Drawing.Point(12, 109);
            this.lblDimen.Name = "lblDimen";
            this.lblDimen.Size = new System.Drawing.Size(62, 13);
            this.lblDimen.TabIndex = 7;
            this.lblDimen.Text = "Dimensões:";
            // 
            // lblQuantidade
            // 
            this.lblQuantidade.AutoSize = true;
            this.lblQuantidade.Location = new System.Drawing.Point(124, 184);
            this.lblQuantidade.Name = "lblQuantidade";
            this.lblQuantidade.Size = new System.Drawing.Size(72, 13);
            this.lblQuantidade.TabIndex = 14;
            this.lblQuantidade.Text = "lblQuantidade";
            // 
            // lblPeso
            // 
            this.lblPeso.AutoSize = true;
            this.lblPeso.Location = new System.Drawing.Point(124, 148);
            this.lblPeso.Name = "lblPeso";
            this.lblPeso.Size = new System.Drawing.Size(41, 13);
            this.lblPeso.TabIndex = 13;
            this.lblPeso.Text = "lblPeso";
            // 
            // lblDimensoes
            // 
            this.lblDimensoes.AutoSize = true;
            this.lblDimensoes.Location = new System.Drawing.Point(124, 109);
            this.lblDimensoes.Name = "lblDimensoes";
            this.lblDimensoes.Size = new System.Drawing.Size(69, 13);
            this.lblDimensoes.TabIndex = 12;
            this.lblDimensoes.Text = "lblDimensoes";
            // 
            // lblModelo
            // 
            this.lblModelo.AutoSize = true;
            this.lblModelo.Location = new System.Drawing.Point(124, 70);
            this.lblModelo.Name = "lblModelo";
            this.lblModelo.Size = new System.Drawing.Size(52, 13);
            this.lblModelo.TabIndex = 11;
            this.lblModelo.Text = "lblModelo";
            // 
            // lblFabricante
            // 
            this.lblFabricante.AutoSize = true;
            this.lblFabricante.Location = new System.Drawing.Point(124, 30);
            this.lblFabricante.Name = "lblFabricante";
            this.lblFabricante.Size = new System.Drawing.Size(67, 13);
            this.lblFabricante.TabIndex = 10;
            this.lblFabricante.Text = "lblFabricante";
            // 
            // lblPreco
            // 
            this.lblPreco.AutoSize = true;
            this.lblPreco.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblPreco.Location = new System.Drawing.Point(10, 243);
            this.lblPreco.Name = "lblPreco";
            this.lblPreco.Size = new System.Drawing.Size(98, 25);
            this.lblPreco.TabIndex = 15;
            this.lblPreco.Text = "lblPreco";
            // 
            // lblDesconto
            // 
            this.lblDesconto.AutoSize = true;
            this.lblDesconto.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDesconto.Location = new System.Drawing.Point(11, 293);
            this.lblDesconto.Name = "lblDesconto";
            this.lblDesconto.Size = new System.Drawing.Size(93, 20);
            this.lblDesconto.TabIndex = 16;
            this.lblDesconto.Text = "lblDesconto";
            // 
            // btnComprar
            // 
            this.btnComprar.Location = new System.Drawing.Point(189, 243);
            this.btnComprar.Name = "btnComprar";
            this.btnComprar.Size = new System.Drawing.Size(84, 70);
            this.btnComprar.TabIndex = 17;
            this.btnComprar.Text = "Comprar";
            this.btnComprar.UseVisualStyleBackColor = true;
            // 
            // frmComprar
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(329, 341);
            this.Controls.Add(this.btnComprar);
            this.Controls.Add(this.lblDesconto);
            this.Controls.Add(this.lblPreco);
            this.Controls.Add(this.lblQuantidade);
            this.Controls.Add(this.lblPeso);
            this.Controls.Add(this.lblDimensoes);
            this.Controls.Add(this.lblModelo);
            this.Controls.Add(this.lblFabricante);
            this.Controls.Add(this.lblQuant);
            this.Controls.Add(this.lblPes);
            this.Controls.Add(this.lblDimen);
            this.Controls.Add(this.lblMod);
            this.Controls.Add(this.lblFab);
            this.Name = "frmComprar";
            this.Text = "Comprar Aparelho";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblMod;
        private System.Windows.Forms.Label lblFab;
        private System.Windows.Forms.Label lblQuant;
        private System.Windows.Forms.Label lblPes;
        private System.Windows.Forms.Label lblDimen;
        private System.Windows.Forms.Label lblQuantidade;
        private System.Windows.Forms.Label lblPeso;
        private System.Windows.Forms.Label lblDimensoes;
        private System.Windows.Forms.Label lblModelo;
        private System.Windows.Forms.Label lblFabricante;
        private System.Windows.Forms.Label lblPreco;
        private System.Windows.Forms.Label lblDesconto;
        private System.Windows.Forms.Button btnComprar;
    }
}