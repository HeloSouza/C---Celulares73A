﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Celulares73A.Model;
using Celulares73A.Model.Entidades;

namespace Celulares73A.Desktop
{
    public partial class frmNovo : Form
    {
        List<Fabricante> fabricantes = new List<Fabricante>();
        public frmNovo()
        {
            InitializeComponent();
        }

        private void frmNovo_Load(object sender, EventArgs e)
        {
            fabricantes = Servico.todosFabricantes();
            cmbFabricante.DataSource = fabricantes;
            cmbFabricante.ValueMember = "id_fabricante";
            cmbFabricante.DisplayMember = "nome";
            cmbFabricante.SelectedIndex = -1;
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            Aparelho ap = new Aparelho();
            ap.Modelo = txtModelo.Text;
            ap.Largura = numLargura.Value;
            ap.Altura = numAltura.Value;
            ap.Espessura = numEspessura.Value;
            ap.Peso = numPeso.Value;
            ap.Quantidade = Convert.ToInt32(numQuantidade.Value);
            ap.Preco = numPreco.Value;
            ap.Desconto = numDesconto.Value;
            ap.Fabricante = fabricantes[cmbFabricante.SelectedIndex];
            Servico.Salvar(ap);
            MessageBox.Show("Cadastro efetivado com sucesso!",
                            "Celular CTI 2022",
                             MessageBoxButtons.OK,
                             MessageBoxIcon.Exclamation);
            this.Close();

        }
    }
}
