﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Celulares73A.Model;
using Celulares73A.Model.Entidades;

namespace Celulares73A.Desktop
{
    public partial class frmNovo : Form
    {
        List<Fabricante> fabricantes = new List<Fabricante>();
        public frmNovo()
        {
            InitializeComponent();
        }

        private void frmNovo_Load(object sender, EventArgs e)
        {
            try
            {
                fabricantes = Servico.todosFabricantes();
                cmbFabricante.DataSource = fabricantes;
                cmbFabricante.ValueMember = "id_fabricante";
                cmbFabricante.DisplayMember = "nome";
                cmbFabricante.SelectedIndex = -1;
            }

            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao realizar o carregamento dos fabricantes!" +
                                "\n\nMais detalhes: " + ex.Message,
                                "Celular CTI 2022", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            
            
        }

        private void btnSalvar_Click(object sender, EventArgs e)
        {
            try
            {

                Aparelho ap = new Aparelho();
                ap.Modelo = txtModelo.Text;
                ap.Largura = numLargura.Value;
                ap.Altura = numAltura.Value;
                ap.Espessura = numEspessura.Value;
                ap.Peso = numPeso.Value;
                ap.Quantidade = Convert.ToInt32(numQuantidade.Value);
                ap.Preco = numPreco.Value;
                ap.Desconto = numDesconto.Value;


                if (cmbFabricante.Text == string.Empty)
                {
                    MessageBox.Show("É necessário preencher o campo Fabricante!",
                                "Celular CTI 2022",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Error);
                    cmbFabricante.Focus();
                }

                else if (txtModelo.Text == "")
                {
                    MessageBox.Show("É necessário preencher o campo Modelo!",
                                "Celular CTI 2022",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Error);
                    txtModelo.Focus();
                }

                else if (numQuantidade.Value == 0)
                {
                    MessageBox.Show("É necessário preencher o campo Quantidade!",
                                "Celular CTI 2022",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Error);
                    numQuantidade.Focus();
                }

                else if (numPreco.Value == 0)
                {
                    MessageBox.Show("É necessário preencher o campo Preço!",
                                "Celular CTI 2022",
                                 MessageBoxButtons.OK,
                                 MessageBoxIcon.Error);
                    numPreco.Focus();
                }

                else
                {
                    ap.Fabricante = fabricantes[cmbFabricante.SelectedIndex];
                    Servico.Salvar(ap);
                    MessageBox.Show("Cadastro efetivado com sucesso!",
                                    "Celular CTI 2022",
                                     MessageBoxButtons.OK,
                                     MessageBoxIcon.Information);
                    this.Close();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao salvar o produto!" +
                                "\n\nMais detalhes: " + ex.Message,
                                "Celular CTI 2022", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
