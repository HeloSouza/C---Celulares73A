﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Celulares73A.Model.Entidades;
using Celulares73A.Model;

namespace Celulares73A.Desktop
{
    public partial class frmPrincipal : Form
    {
        List<Aparelho> aparelhos = new List<Aparelho>();
        
        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            aparelhos = Servico.PesquisarAparelho();
            dtvCelulares.DataSource = aparelhos;
        }

       
    }
}
