﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Celulares73A.Model.Entidades;
using Celulares73A.Model;

namespace Celulares73A.Desktop
{
    public partial class frmPrincipal : Form
    {
        List<Aparelho> aparelhos = new List<Aparelho>();
        List<Fabricante> fabricantes = new List<Fabricante>();

        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            aparelhos = Servico.PesquisarAparelho();
            lstCelulares.DataSource = aparelhos;

            fabricantes = Servico.todosFabricantes();
            cmbFabricante.DataSource = fabricantes;
            cmbFabricante.ValueMember = "id_fabricante";
            cmbFabricante.DisplayMember = "nome";
            cmbFabricante.SelectedIndex = -1;
        }

        private void btnBuscarFabricante_Click(object sender, EventArgs e)
        {
            aparelhos = Servico.PesquisarAparelho(fabricantes[cmbFabricante.SelectedIndex]);
            lstCelulares.DataSource = aparelhos;
        }

        private void btnBuscarModelo_Click(object sender, EventArgs e)
        {
            aparelhos = Servico.PesquisarAparelho(txtModelo.Text);
            lstCelulares.DataSource = aparelhos;


        }
    }
}
