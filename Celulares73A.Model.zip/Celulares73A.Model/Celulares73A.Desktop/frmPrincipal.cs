﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Celulares73A.Model.Entidades;
using Celulares73A.Model;

namespace Celulares73A.Desktop
{
    public partial class frmPrincipal : Form
    {
        List<Aparelho> aparelhos = new List<Aparelho>();
        List<Fabricante> fabricantes = new List<Fabricante>();

        public frmPrincipal()
        {
            InitializeComponent();
        }

        private void frmPrincipal_Load(object sender, EventArgs e)
        {
            try
            {
                aparelhos = Servico.PesquisarAparelho();
                lstCelulares.DataSource = aparelhos;
                fabricantes = Servico.todosFabricantes();
                cmbFabricante.DataSource = fabricantes;
                cmbFabricante.ValueMember = "id_fabricante";
                cmbFabricante.DisplayMember = "nome";
                cmbFabricante.SelectedIndex = -1;
            }

            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro no carregamento!" +
                                "\n\nMais detalhes: " + ex.Message,
                                "Celular CTI 2022", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBuscarFabricante_Click(object sender, EventArgs e)
        {
            try
            {
                aparelhos = Servico.PesquisarAparelho(fabricantes[cmbFabricante.SelectedIndex]);
                lstCelulares.DataSource = aparelhos;
            }

            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao pesquisar o fabricante!" +
                                "\n\nMais detalhes: " + ex.Message,
                                "Celular CTI 2022", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBuscarModelo_Click(object sender, EventArgs e)
        {
            try
            {
                aparelhos = Servico.PesquisarAparelho(txtModelo.Text);
                lstCelulares.DataSource = aparelhos;
            }

            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao pesquisar o modelo!" +
                                "\n\nMais detalhes: " + ex.Message,
                                "Celular CTI 2022", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnBuscaPreco_Click(object sender, EventArgs e)
        {
            try
            {
                if (numPrecoMin.Value <= numPrecoMax.Value)
                {
                    aparelhos = Servico.PesquisarAparelho(numPrecoMin.Value, numPrecoMax.Value);

                    lstCelulares.DataSource = aparelhos;

                    numPrecoMax.Focus();

                    return;
                }
                else
                {
                    MessageBox.Show("O preço máximo deve ser maior ou igual ao preço mínimo",
                                    "Celular CTI 2022",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Exclamation);
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro ao pesquisar os preços!" +
                                "\n\nMais detalhes: " + ex.Message,
                                "Celular CTI 2022", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnComprar_Click(object sender, EventArgs e)
        {
            try
            {
                if (lstCelulares.SelectedIndex != -1)
                {
                    frmComprar compra = new frmComprar(aparelhos[lstCelulares.SelectedIndex]);
                    compra.ShowDialog();
                }

                else
                {
                    MessageBox.Show("Você deve selecionar um aparelho!",
                                    "Celular CTI 2022",
                                    MessageBoxButtons.OK,
                                    MessageBoxIcon.Exclamation);
                    lstCelulares.Focus();
                    //return;
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro na compra!" +
                                "\n\nMais detalhes: " + ex.Message,
                                "Celular CTI 2022", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void frmPrincipal_Activated(object sender, EventArgs e)
        {
            aparelhos = Servico.PesquisarAparelho();
            lstCelulares.DataSource = aparelhos;
        }

        private void btnNovo_Click(object sender, EventArgs e)
        {
            frmNovo ap = new frmNovo();
            ap.ShowDialog();
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
