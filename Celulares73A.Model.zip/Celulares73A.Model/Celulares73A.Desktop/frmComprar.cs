﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Celulares73A.Model;
using Celulares73A.Model.Entidades;

namespace Celulares73A.Desktop
{
    public partial class frmComprar : Form
    {
        Aparelho ap = new Aparelho();

        public frmComprar(Aparelho ap) //construtor da classe
        {
            InitializeComponent();

            this.ap = ap;
        }

        private void frmComprar_Load(object sender, EventArgs e)
        {
            try
            {
                lblFabricante.Text = lblFabricante.Text.PadRight(20) + ap.Fabricante.Nome;
                lblModelo.Text = lblModelo.Text.PadRight(20) + ap.Modelo;
                lblPreco.Text = lblPreco.Text.PadRight(12) + ap.Preco.ToString("C");
                lblDesconto.Text = lblDesconto.Text.PadRight(12) + ap.Desconto;
                lblPeso.Text = lblPeso.Text.PadRight(20) + ap.Peso;
                lblQuantidade.Text = lblQuantidade.Text.PadRight(20) + ap.Quantidade;
                lblDimensoes.Text = lblDimensoes.Text.PadRight(20) + Convert.ToInt32(ap.Largura) + " x " + Convert.ToInt32(ap.Altura) + " x " + Convert.ToInt32(ap.Espessura);
            }

            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro no carregamento!" +
                                "\n\nMais detalhes: " + ex.Message,
                                "Celular CTI 2022", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnComprar_Click(object sender, EventArgs e)
        {
            try
            {
                if (ap.Quantidade <= 0)
                {
                    MessageBox.Show("Não há esse produto no estoque!",
                                   "Celular CTI 2022",
                                   MessageBoxButtons.OK,
                                   MessageBoxIcon.Error);
                    this.Close();
                }
                else
                {
                    Servico.FazerPedido(ap, txtObservacao.Text);
                    MessageBox.Show("Pedido efetivado com sucesso!",
                                       "Celular CTI 2022",
                                       MessageBoxButtons.OK,
                                       MessageBoxIcon.Information);
                    this.Close();
                }
            }

            catch (Exception ex)
            {
                MessageBox.Show("Ocorreu um erro na compra!" +
                                "\n\nMais detalhes: " + ex.Message,
                                "Celular CTI 2022", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnVoltar_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
