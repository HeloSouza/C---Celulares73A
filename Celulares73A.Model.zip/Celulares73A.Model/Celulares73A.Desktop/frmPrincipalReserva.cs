﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Celulares73A.Model.Entidades;
using Celulares73A.Model;

namespace Celulares73A.Desktop
{
    public partial class frmPrincipalReserva : Form
    {
        List<Aparelho> aparelhos = new List<Aparelho>();

        public frmPrincipalReserva()
        {
            InitializeComponent();
        }

        private void frmPrincipalReserva_Load(object sender, EventArgs e)
        {
            aparelhos = Servico.PesquisarAparelho();
            listBox1.DataSource = aparelhos;

        }
    }
}
